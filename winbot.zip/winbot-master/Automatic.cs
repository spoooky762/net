using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.Net.FtpClient;

using com.google.zxing;
using com.google.zxing.common;
using com.google.zxing.qrcode;

namespace gutenberg.collect
{
	public class Automatic
	{
		public Automatic (string scanDir, Manifest manifest)
		{
			this.scanDir = scanDir;
			this.manifest = manifest;
			this.fataphat = new FaTaPhat();
			this.Initialize();
		}

		public bool Execute()
		{
			Scan scan = null;
			String scanKey = null, scanValue = null;
			int scanRotation = 0;
			Result QRCodeResult = null;

			Hashtable hints = new Hashtable();
			hints.Add(DecodeHintType.TRY_HARDER, Boolean.TrueString);

			fataphat.Connect();
			IEnumerable scanFiles = Directory.EnumerateFiles(scanDir,
				"*" + Scan.AUTO_PROCESS);
			foreach (string scanFile in scanFiles) {

				// 1. Detect QR Code
				// 2. Extract information from it
				// 3. fataphat check if already sent
				// 4. fataphat send!
				QRCodeResult = DetectQRC(scanFile, hints);
				if (QRCodeResult == null) {
					string undetectable = scanFile.Replace(
						Scan.AUTO_PROCESS,
						Scan.MANUAL_PROCESS);
					File.Move(scanFile, undetectable);
					continue;
				}

				if (QRCodeResult.Text.Equals(BLANK_PAGE_CODE)) {
					File.Delete(scanFile);
					continue;
				}

				ResultPoint[] points = QRCodeResult.ResultPoints;
				// The result points for a QRCode reported in this order
				// (0:bottom left, 1:top left, 2:top right, 3:bottom right)
				scanRotation = points[0].Y > points[1].Y ? 0 : 1;
				scanKey = QRCodeResult.Text;
				scanValue = manifest.Get(scanKey);
				Console.WriteLine("scanValue " + scanValue);
				if (scanValue == null) {
					string cantProcess = scanFile.Replace(
						Scan.AUTO_PROCESS,
						Scan.MANUAL_PROCESS);
					File.Move(scanFile, cantProcess);
					continue;
				}

				scan = new Scan(scanKey, scanValue, scanRotation, scanFile);
				scan.Process(fataphat);
			}
			manifest.Remove(scanKey);

			return false;
		}

		private Result DetectQRC(string file, Hashtable hints)
		{
			Image img = null;
			LuminanceSource source = null;
			BinaryBitmap bitmap = null;
			Binarizer binarizer = null;
			Reader reader = null;
			Result QRCodeResult = null;

			img = Image.FromFile(file);
			Bitmap bmp = new Bitmap(img);
			source = new RGBLuminanceSource(bmp, img.Width, img.Height);

			ZXingConfig[] configs = ZXingConfig.getInstances(source);
			foreach (ZXingConfig config in configs) {

				reader = config.reader;
				binarizer = config.binarizer;
				bitmap = new BinaryBitmap(binarizer);
				try {
					QRCodeResult = reader.decode(bitmap, hints);
				} catch (Exception) {
				}
			}
			return QRCodeResult;
		}

		private void Initialize()
		{
			string[] scanFiles = Directory.GetFiles(scanDir);
			string pickedUp = null;
			foreach (string file in scanFiles) {

				// skip directories and files being processed
				if (Directory.Exists(file))
					continue;

				if (file.EndsWith(Scan.GRDNS_EXTNSN))
					continue;

				pickedUp = file + Scan.AUTO_PROCESS;
				File.Move(file, pickedUp);
			}
		}

		private string scanDir;
		private Manifest manifest;
		private FaTaPhat fataphat;
		private const string BLANK_PAGE_CODE = "0";
	}

	class ZXingConfig
	{

		public static ZXingConfig[] getInstances(LuminanceSource source)
		{

			ZXingConfig[] configs = new ZXingConfig[2];

			configs[0] = new ZXingConfig();
			configs[0].binarizer = new HybridBinarizer(source);
			configs[0].reader = new QRCodeReader();

			configs[1] = new ZXingConfig();
			configs[1].binarizer = new GlobalHistogramBinarizer(source);
			configs[1].reader = new QRCodeReader();

			return configs;
		}

		public Binarizer binarizer;
		public Reader    reader;

	}

}

