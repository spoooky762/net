using System;
using System.Windows.Forms;

namespace gutenberg.collect
{
	public class Driver
	{
		public static void Main(String[] args)
		{
			MainPanel panel = new MainPanel();
			Application.Run(panel);
		}
	}
}

