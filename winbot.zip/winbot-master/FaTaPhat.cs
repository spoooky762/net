using System;
using System.IO;
using System.Net;
using System.Net.FtpClient;
using System.Collections.Specialized;

namespace gutenberg.collect
{
	public class FaTaPhat
	{
		
		public static NameValueCollection serverProps;
		
		public FaTaPhat ()
		{
			this.server = serverProps["hostname"];
			this.login = serverProps["login"];
			this.password = serverProps["password"];
			this.bankroot = serverProps["bankroot"];
		}

		public void Connect()
		{
			if (client != null && client.IsConnected)
				return;

			client = new FtpClient();
			client.Host = server;
			client.Credentials = new NetworkCredential(login, password);
			client.DataConnectionType = FtpDataConnectionType.PASV;
			client.Connect();
		}
		
		public void Disconnect()
		{
			if (client != null && client.IsConnected)
				client.Disconnect();
		}
		
		public bool Exists(string remote)
		{
			remote = bankroot + "/" + remote;
			return client.FileExists(remote);
		}
		
		public bool Put(string local, string remote, FtpDataType fileType)
		{
			remote = bankroot + "/" + remote;
			byte[] buffer = File.ReadAllBytes(local);
			using (Stream ostream = client.OpenWrite(remote, fileType)) {
				ostream.Write(buffer, 0, buffer.Length);
				ostream.Close();
			}
			return true;
		}
		
		public bool Get(string local, string remote, FtpDataType fileType)
		{
			remote = bankroot + "/" + remote;
			Stream ostream = File.Create(local);
			byte[] buffer = new byte[1024];
			int bytesRead = 0; Console.WriteLine(remote);
			using (Stream istream = client.OpenRead(remote, fileType)) {
				while ((bytesRead = istream.Read(buffer, 0, buffer.Length)) != 0) {
					ostream.Write(buffer, 0, bytesRead);
					ostream.Flush();
				}
				ostream.Close();
				istream.Close();
			}
			return true;
		}
			
		private FtpClient client;
		private string server, login, password, bankroot;
	}
}
