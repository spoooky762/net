using System;
using System.IO;
using System.Net.FtpClient;

namespace gutenberg.collect
{
	public class Scan
	{
		
		public static string AUTO_PROCESS = ".ap.grdns";
		public static string MANUAL_PROCESS = ".mp.grdns";
		public static string CANT_PROCESS = ".cp.grdns";
		public static string GRDNS_EXTNSN = ".grdns";
		
		public Scan (string base36ScanId, string scanContext, int scanRotation,
            string scanFile)
		{
			// scanContext=[studentId]-[first name]-[last name]-[quiz_id]
			// [testpaper_id]-[question_no]-[page_no]-[totalPages]
			char[] sep = {'-'};
			string[] tokens = scanContext.Split(sep);
			string quizId = tokens[3], testpaperId = tokens[4], id = tokens[0],
				page = tokens[6];
			if (testpaperId.Equals("0")) {
				FileInfo finfo = new FileInfo(scanFile);				
				testpaperId = finfo.Length.ToString();
				nameInLocker = string.Format("locker/{0}-{1}/{2}",
					quizId, id, testpaperId);
			} else {
				nameInLocker = string.Format("locker/{0}-{1}/{2}",
					quizId, testpaperId, base36ScanId);
			}
			scanId = string.Format("{0}-{1}-{2}-{3}", quizId, testpaperId, id, page);
			nameInStaging = string.Format("staging/{0}_{1}_{2}",
				base36ScanId, scanId, scanRotation);
			this.scanFile = scanFile;
		}
		
		public void Process(FaTaPhat fataphat)
		{			
			string rightSideUp, upsideDown;
			int length = nameInStaging.Length;
			rightSideUp = nameInStaging.Substring(0, length - 1) + "0";
			upsideDown = nameInStaging.Substring(0, length - 1) + "1";
			
			// We receive a scan only once, ALWAYS check if
			// scan is already in the bank (locker or staging)
			if (fataphat.Exists(nameInLocker) ||
            	fataphat.Exists(rightSideUp) ||
				fataphat.Exists(upsideDown)) {
				File.Delete(scanFile);
			} else {
				if (fataphat.Put(scanFile, nameInStaging, FtpDataType.Binary)) {
					File.Delete(scanFile);
				} else {
					throw new Exception("N/w issue? File transfer (PUT) failed");
				}
			}
		}
		
		public string id, quizId, testpaperId, firstName, lastName, questionId,
            pageNumber, totalPages, scanId, base36ScanId, rotation,
            nameInStaging, nameInLocker;
		private string scanFile;
		
	}
}

