winbot
======

.NET version of scanbot written in C# using Mono