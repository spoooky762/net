using System;
using System.IO;
using System.Xml;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Specialized;

namespace gutenberg.collect
{
	public class MainPanel : Form
	{
		public MainPanel ()
		{
			scanDir = System.Environment.GetFolderPath
				(Environment.SpecialFolder.Desktop) + "/gradians.com";
			FaTaPhat.serverProps = GetServerProps("local");
			Manifest manifest = new Manifest(scanDir);
			PreparePanel();
		}

		private void ButtonClick(Object o, EventArgs args)
		{
			Console.WriteLine(o.ToString());
		}

		private NameValueCollection GetServerProps(String runmode)
		{
			string exception =
				"Send 'Error setting Server Properties' to help@gradians.com";
			/**
         ****************************************************************
         * WARNING: DO NOT EDIT THIS BLOCK OF CODE, YOU RISK SENDING
         *          SCANS TO PRODUCTION BY ACCIDENT
         ****************************************************************
         */
			NameValueCollection properties = new NameValueCollection();
			if (runmode.Equals("remote")) {
				properties.Add("hostname", "109.74.201.62");
				properties.Add("login", "gutenberg");
				properties.Add("password", "shibb0leth");
				properties.Add("bankroot", "/home/gutenberg/bank");
			} else if (runmode.Equals("local")) {
				/**
             *********************************************************
             ** configuration file has your password, at least it's in a
             ** hidden folder in YOUR $HOME.
             *********************************************************
             */
				string configFile = System.Environment.GetFolderPath(
					Environment.SpecialFolder.Personal) + "/.scanLoader/config.xml";
				XmlDocument config = new XmlDocument();
				config.LoadXml(File.ReadAllText(configFile));
				XmlNodeList elements = config.GetElementsByTagName("entry");
				foreach (XmlNode element in elements) {
					properties.Add(element.Attributes["key"].Value, element.InnerText);
				}
			} else {
				throw new Exception(exception + " No runmode specified");
			}
			return properties;
		}

		private void PreparePanel()
		{
			btnStart = new Button();
			btnStart.Size = new Size(240, 90);
			btnStart.Location = new Point(5, 5);
			btnStart.Text = "|>";
			btnStart.Click += new EventHandler(ButtonClick);
			btnStart.BackColor = Color.Pink;
			Controls.Add(btnStart);

			lblStatus = new Label();
			lblStatus.Size = new Size(480, 90);
			lblStatus.Location = new Point(250, 5);
			lblStatus.BorderStyle = BorderStyle.FixedSingle;
			lblStatus.Font = new Font("Sans Serif", 13);
			lblStatus.Text = "Ready to rock and roll\n Looking in " + scanDir;
			Controls.Add(lblStatus);

			this.Size = new Size(5+btnStart.Width+5+lblStatus.Width+13, 5+90+5+25);
			this.StartPosition = FormStartPosition.CenterScreen;
			this.MaximizeBox = false;
		}

		private string scanDir;
		private Button btnStart;
		private Label lblStatus;
	}
}

