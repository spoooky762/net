using System;
using System.IO;
using System.Collections.Specialized;
using System.Net.FtpClient;

namespace gutenberg.collect
{
	public class Manifest
	{
		public Manifest (string scanDir)
		{
			manifest = new NameValueCollection();
			leftovers = scanDir + "/" + filename;
			if (File.Exists(leftovers)) {
				this.LoadFile(leftovers);
			}
			fataphat = new FaTaPhat();
		}

		public string Lookup(string scanKey)
		{
			return manifest[scanKey];
		}

		public string Get(string scanKey)
		{
			if (manifest[scanKey] == null)
			{
				FetchManifest(scanKey);
			}
			return manifest[scanKey];
		}

		public void Remove(string scanKey)
		{
			manifest.Remove(scanKey);
		}

		public string[] GetKeys()
		{
			return manifest.AllKeys;
		}

		private void FetchManifest(string base36Id)
		{
			string key = null;
			string keyFile = null;
			string format = null;
			if (base36Id.Contains("-")) {// suggestion
				key = base36Id;
				format = "front-desk/teachers/{0}/petty-cash/keyFile";
			} else {
				key = base36Id.Substring(0, 6);
				format = "atm/{0}/keyFile";
			}
			keyFile = string.Format(format, key);
			string local = System.DateTime.Now.Millisecond.ToString();
			fataphat.Connect();
			if (fataphat.Exists(keyFile)) {
				fataphat.Get(local, keyFile, FtpDataType.ASCII);
				this.LoadFile(local);
				File.Delete(local);
			}
			fataphat.Disconnect();
		}

		private void LoadFile(string file)
		{
			string[] lines = File.ReadAllLines(file);
			string[] tokens = null;
			char[] sep = {':'};
			foreach (string line in lines) {
				tokens = line.Split(sep);
				manifest.Add(tokens[0], tokens[1]);
			}
		}

		private FaTaPhat fataphat;
		private NameValueCollection manifest;
		private string leftovers;
		private const string filename = "leftovers.grdns";

	}
}

